import streamlit as st
import pandas as pd
import plotly.express as px
import openpyxl


ARQUIVO = "dados.csv"

TITULO_ABA = "saeb_aprendizado_territorios-7-2023-"
TITULO_PAINEL = "saeb_aprendizado_territorios-7-2023-"

COLUNA_insuficiente = "insuficiente"
COLUNA_básico = "basico"
COLUNA_proficiente = "proficiente"

COLUNA_avançado = "avançado"
COLUNA_adequado = "adequado"

ITEM_1 = "lingua portuguesa insuficiente"
ITEM_2 = "matematica insuficiente"

COR_1 = "#FF6B6B"
COR_2 = "#00F5D4"

COLUNAS_DIMENSOES = ["insuficiente", "básico", "proficiente", "avançado ", "adequado"]
DIMENSAO_X = "lingua portuguesa insuficiente"
DIMENSAO_Y = "matematica insuficiente"

FONTE = "https://www.gov.br/inep "



st.set_page_config(page_title=TITULO_ABA, layout="wide")


def carregar_dados(arquivo):
    if arquivo.lower().endswith((".xlsx", ".xls")):
        tabela = pd.read_excel(arquivo, engine="openpyxl")
    else:
        try:
            tabela = pd.read_csv(arquivo, sep=None, engine="python", encoding="utf-8-sig")
        except UnicodeDecodeError:
            tabela = pd.read_csv(arquivo, sep=None, engine="python", encoding="latin-1")
    tabela.columns = tabela.columns.astype(str).str.strip()
    return tabela


def para_numero(coluna):
    if pd.api.types.is_numeric_dtype(coluna):
        return coluna
    return pd.to_numeric(coluna.astype(str).str.strip().str.replace(",", ".", regex=False), errors="coerce")


df = carregar_dados(ARQUIVO)

colunas_faltando = [c for c in COLUNA_insuficiente] if c not in df.columns
if colunas_faltando:
    st.error(f"Estas colunas nao existem no arquivo: {colunas_faltando}")
    st.write("Colunas que existem no arquivo:", list(df.columns))
    st.stop()

dimensoes = [c for c in COLUNAS_DIMENSOES if c in df.columns]

df[COLUNA_insuficiente ] = df[COLUNA_insuficiente ].astype(str).str.strip()
df[COLUNA_básico] = para_numero(df[COLUNA_básico])
df[COLUNA_proficiente] = para_numero(df[COLUNA_proficiente])
for coluna in dimensoes:
    df[coluna] = para_numero(df[coluna])

filtro = df[COLUNA_insuficiente ].isin([ITEM_1, ITEM_2])
if COLUNA_avançado and COLUNA_avançado in df.columns:
    filtro = filtro & (df[COLUNA_avançado].astype(str).str.strip() == COLUNA_adequado)

df_filtrado = pd.concat([df[filtro & (df[COLUNA_insuficiente 
] == item)].sort_values(COLUNA_básico) for item in [ITEM_1, ITEM_2]])

itens_faltando = [i for i in [ITEM_1, ITEM_2] if i not in df_filtrado[COLUNA_insuficiente 
].values]
if itens_faltando:
    st.error(f"Nenhuma linha encontrada para {itens_faltando}. Confira a escrita na PARTE 1.")
    st.write(f"Nomes que existem na coluna {COLUNA_insuficiente 
}:", sorted(df[COLUNA_insuficiente].unique()))
    if COLUNA_avançado and COLUNA_avançado in df.columns:
        st.write(f"Valores que existem na coluna {COLUNA_avançado}:", sorted(df[COLUNA_avançado].astype(str).unique()))
    st.stop()

df_tabela = df_filtrado[[COLUNA_insuficiente 
, COLUNA_básico, COLUNA_proficiente]]

cores = {ITEM_1: COR_1, ITEM_2: COR_2}
ano_inicio = int(df_tabela[COLUNA_básico].min())
ano_fim = int(df_tabela[COLUNA_básico].max())
fundo = dict(paper_bgcolor="#111827", plot_bgcolor="#111827")

df_ultimo_ano = df_filtrado[df_filtrado[COLUNA_básico] == ano_fim]

st.title(TITULO_PAINEL)

st.sidebar.header("Controles")
opcao = st.sidebar.radio("Selecione a visualização:", ["Tabela", "Gráficos"])


if opcao == "Tabela":
    st.header(f"Tabela do {COLUNA_proficiente}")
    st.dataframe(df_tabela, hide_index=True)

elif opcao == "Gráficos":
    st.header(f"Gráficos do {COLUNA_proficiente} — {ITEM_1} e {ITEM_2}")

    st.subheader(f"1. Gráfico de Linha — {ITEM_1}")
    df_item_1 = df_tabela[df_tabela[COLUNA_insuficiente 
] == ITEM_1]
    fig_linha_1 = px.line(
        df_item_1,
        x=COLUNA_básico,
        y=COLUNA_proficiente,
        markers=True,
        title=f"Evolução do {COLUNA_proficiente} — {ITEM_1} ({ano_inicio} a {ano_fim})",
        template="plotly_dark"
    )
    fig_linha_1.update_traces(line_color=COR_1, line_width=3, marker_size=8)
    fig_linha_1.update_xaxes(type="category")
    fig_linha_1.update_layout(**fundo)
    st.plotly_chart(fig_linha_1, theme=None)

    st.subheader(f"2. Gráfico de Linha — {ITEM_2}")
    df_item_2 = df_tabela[COLUNA_insuficiente 
] == ITEM_2
    fig_linha_2 = px.line(
        df_item_2,
        x=COLUNA_básico,
        y=COLUNA_proficiente,
        markers=True,
        title=f"Evolução do {COLUNA_proficiente} — {ITEM_2} ({ano_inicio} a {ano_fim})",
        template="plotly_dark"
    )
    fig_linha_2.update_traces(line_color=COR_2, line_width=3, marker_size=8)
    fig_linha_2.update_xaxes(type="category")
    fig_linha_2.update_layout(**fundo)
    st.plotly_chart(fig_linha_2, theme=None)

    st.subheader("3. Gráfico de Barras Agrupadas")
    fig_barras = px.bar(
        df_tabela,
        x=COLUNA_básico,
        y=COLUNA_proficiente,
        color=COLUNA_insuficiente
,
        barmode="group",
        title=f"Comparativo Anual de {COLUNA_proficiente} (Barras Agrupadas)",
        color_discrete_map=cores,
        template="plotly_dark"
    )
    fig_barras.update_xaxes(type="category")
    fig_barras.update_layout(**fundo)
    st.plotly_chart(fig_barras, theme=None)

    st.subheader(f"4. Gráfico de Barras Empilhadas (Dimensões em {ano_fim})")
    if dimensoes:
        dados_empilhado = df_ultimo_ano.melt(
            id_vars=[COLUNA_insuficiente],
            value_vars=dimensoes,
            var_name="Dimensao",
            value_name="Valor"
        )
        fig_empilhado = px.bar(
            dados_empilhado,
            x=COLUNA_insuficiente,
            y="Valor",
            color="Dimensao",
            barmode="stack",
            title=f"Composição do {COLUNA_proficiente} por Dimensão — Ano {ano_fim} (Barras Empilhadas)",
            template="plotly_dark"
        )
        fig_empilhado.update_layout(**fundo)
        st.plotly_chart(fig_empilhado, theme=None)
    else:
        st.info("Sem colunas de dimensões. Confira COLUNAS_DIMENSOES na PARTE 1.")

    st.subheader("5. Gráfico de Pizza")
    dados_pizza = df_ultimo_ano[[COLUNA_insuficiente, COLUNA_proficiente]]
    fig_pizza = px.pie(
        dados_pizza,
        names=COLUNA_insuficiente,
        values=COLUNA_proficiente,
        title=f"Proporção do {COLUNA_proficiente} entre {ITEM_1} e {ITEM_2} ({ano_fim})",
        color=COLUNA_insuficiente,
        color_discrete_map=cores,
        template="plotly_dark"
    )
    fig_pizza.update_traces(textinfo="percent+label+value")
    fig_pizza.update_layout(**fundo)
    st.plotly_chart(fig_pizza, theme=None)

    st.subheader("6. Gráfico de Radar (px.line_polar)")
    if dimensoes:
        dados_radar = df_ultimo_ano.melt(
            id_vars=[COLUNA_insuficiente],
            value_vars=dimensoes,
            var_name="Dimensao",
            value_name="Nota"
        )
        fig_radar = px.line_polar(
            dados_radar,
            r="Nota",
            theta="Dimensao",
            color=COLUNA_insuficiente,
            line_close=True,
            title=f"Perfil Multidimensional (Gráfico de Radar - {ano_fim})",
            color_discrete_map=cores,
            template="plotly_dark"
        )
        fig_radar.update_traces(fill="toself")
        fig_radar.update_layout(
            polar=dict(bgcolor="#1E293B", radialaxis=dict(visible=True, range=[0, 1])),
            paper_bgcolor="#111827"
        )
        st.plotly_chart(fig_radar, theme=None)
    else:
        st.info("Sem colunas de dimensões. Confira COLUNAS_DIMENSOES na PARTE 1.")

    st.subheader("7. Gráfico de Área")
    fig_area = px.area(
        df_tabela,
        x=COLUNA_básico,
        y=COLUNA_proficiente,
        color=COLUNA_insuficiente,
        title=f"Evolução em Área do {COLUNA_proficiente} ({ano_inicio} a {ano_fim})",
        color_discrete_map=cores,
        template="plotly_dark"
    )
    fig_area.update_xaxes(type="category")
    fig_area.update_layout(**fundo)
    st.plotly_chart(fig_area, theme=None)

    st.subheader("8. Gráfico de Dispersão")
    if DIMENSAO_X in df_filtrado.columns and DIMENSAO_Y in df_filtrado.columns:
        fig_dispersao = px.scatter(
            df_filtrado,
            x=DIMENSAO_X,
            y=DIMENSAO_Y,
            color=COLUNA_insuficiente,
            size=COLUNA_proficiente,
            hover_data=[COLUNA_básico],
            title=f"Dispersão: {DIMENSAO_X} vs {DIMENSAO_Y} (Tamanho = {COLUNA_proficiente})",
            color_discrete_map=cores,
            template="plotly_dark"
        )
        fig_dispersao.update_layout(**fundo)
        st.plotly_chart(fig_dispersao, theme=None)
    else:
        st.info("Confira DIMENSAO_X e DIMENSAO_Y na PARTE 1.")

    st.subheader("9. Gráfico Boxplot")
    fig_box = px.box(
        df_tabela,
        x=COLUNA_insuficiente,
        y=COLUNA_proficiente,
        color=COLUNA_insuficiente,
        points="all",
        title=f"Distribuição Estatística do {COLUNA_proficiente} (Boxplot)",
        color_discrete_map=cores,
        template="plotly_dark"
    )
    fig_box.update_layout(**fundo)
    st.plotly_chart(fig_box, theme=None)


st.markdown("---")
st.caption(FONTE)